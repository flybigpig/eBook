package com.sham.image;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.progress.BackgroundTaskQueue;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.Task;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MagicAction extends AnAction {

  private List<String> imageList = new ArrayList<>();

  @Override
  public void actionPerformed(@NotNull AnActionEvent e) {
    Project project = e.getProject();
    if (project == null) {
      return;
    }
    new BackgroundTaskQueue(project, "MagicImage")
        .run(
            new Task.Backgroundable(project, "MagicImage") {
              @Override
              public void run(@NotNull ProgressIndicator progressIndicator) {
                progressIndicator.setText("MagicImage");
                progressIndicator.setIndeterminate(true);
                Project myProject = getProject();
                if (myProject == null) {
                  return;
                }
                String basePath = myProject.getBasePath();
                iteratorDir(basePath);
                try {
                  for (String str : imageList) {
                    ChangePixelAction.produceSimilarImg(str);
                  }
                } catch (Exception e1) {
                  e1.printStackTrace();
                }
                ApplicationManager.getApplication()
                    .invokeLater(
                        () ->
                            Messages.showMessageDialog(
                                project,
                                "Magic Image Complete!",
                                "MagicImage",
                                Messages.getInformationIcon()));
              }
            });
  }

  private void iteratorDir(String path) {
    File file = new File(path);
    if (file.isDirectory()) {
      File[] children = file.listFiles();
      if (children == null) {
        return;
      }
      for (File child : children) {
        if (child.isDirectory()) {
          iteratorDir(child.getAbsolutePath());
        } else {
          filterImage(child);
        }
      }
    } else {
      filterImage(file);
    }
  }

  private void filterImage(File file) {
    String name = file.getName();
    int index = name.lastIndexOf(".");
    if (index <= 0) {
      return;
    }
    String suffix = name.substring(index).toLowerCase();
    if (".png".equals(suffix) || ".jpg".equals(suffix) || ".jpeg".equals(suffix)) {
      imageList.add(file.getAbsolutePath());
    }
  }
}
