package com.sham.image;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Random;

class ChangePixelAction {

  static void produceSimilarImg(String imagePath) throws Exception {
    File sourceFile = new File(imagePath);
    BufferedImage img = ImageIO.read(sourceFile);
    int width = img.getWidth();
    int height = img.getHeight();
    int size = (int) (Math.min(width, height) * 0.1f);
    Random random = new Random();
    for (int i = 0; i < size; i++) {
      int x = random.nextInt(width);
      int y = random.nextInt(height);
      int p = img.getRGB(x, y);
      int a = (p >> 24) & 0xff;
      int r = (p >> 16) & 0xff;
      int g = (p >> 8) & 0xff;
      int b = p & 0xff;
      if (a == 0 && r == 0 && g == 0 && b == 0) {
        continue;
      }
      int value = random.nextInt(10);
      if (r + value < 255) {
        r += value;
      }
      if (g + value < 255) {
        g += value;
      }
      if (b + value < 255) {
        b += value;
      }
      p = (a << 24) | (r << 16) | (g << 8) | b;
      img.setRGB(x, y, p);
    }
    ImageIO.write(img, getFileExtension(sourceFile), sourceFile);
  }

  private static String getFileExtension(File file) {
    String fileName = file.getName();
    if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
      return fileName.substring(fileName.lastIndexOf(".") + 1);
    else return "";
  }
}
